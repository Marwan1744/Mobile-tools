package com.example.mobiletools;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView result;
    int pad=18;

    TextView title(String s) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(24); t.setTextColor(Color.rgb(25,25,25));
        t.setPadding(pad,pad,pad,pad); t.setGravity(Gravity.CENTER); return t;
    }
    Button btn(String s, View.OnClickListener l) {
        Button b=new Button(this); b.setText(s); b.setTextSize(17); b.setOnClickListener(l);
        b.setAllCaps(false); return b;
    }
    EditText input(String hint) {
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(17); e.setPadding(pad,pad,pad,pad);
        return e;
    }
    void showHome() {
        root.removeAllViews(); root.addView(title("🧰 أدوات الجوال الشاملة"));
        root.addView(btn("🧮 الحاسبة", v -> calculator()));
        root.addView(btn("📊 حساب النسبة المئوية", v -> percent()));
        root.addView(btn("🔄 تحويل الوحدات", v -> converter()));
        root.addView(btn("🔳 إنشاء QR", v -> qr()));
        root.addView(btn("📝 أدوات النص", v -> textTools()));
        TextView ad=new TextView(this); ad.setText("مساحة إعلانية — ستُضاف لاحقًا"); ad.setGravity(Gravity.CENTER);
        ad.setPadding(pad,40,pad,40); root.addView(ad);
    }
    void page(String heading) { root.removeAllViews(); root.addView(title(heading)); root.addView(btn("⬅ الرئيسية", v->showHome())); }
    void calculator() {
        page("🧮 الحاسبة");
        EditText a=input("الرقم الأول"); EditText b=input("الرقم الثاني"); root.addView(a);root.addView(b);
        result=new TextView(this);result.setTextSize(20);result.setPadding(pad,pad,pad,pad);root.addView(result);
        LinearLayout row=new LinearLayout(this);
        String[] ops={"+","−","×","÷"};
        for(String op:ops) row.addView(btn(op,v->{try{
            double x=Double.parseDouble(a.getText().toString()), y=Double.parseDouble(b.getText().toString()), z=0;
            if(op.equals("+"))z=x+y; if(op.equals("−"))z=x-y; if(op.equals("×"))z=x*y;
            if(op.equals("÷")){if(y==0){result.setText("لا يمكن القسمة على صفر");return;} z=x/y;}
            result.setText("النتيجة: "+z);
        }catch(Exception e){result.setText("أدخل رقمين صحيحين");}}));
        root.addView(row);
    }
    void percent() {
        page("📊 النسبة المئوية");
        EditText value=input("القيمة"); EditText pct=input("النسبة %"); root.addView(value);root.addView(pct);
        result=new TextView(this);result.setTextSize(20);root.addView(result);
        root.addView(btn("احسب",v->{try{
            double x=Double.parseDouble(value.getText().toString()), p=Double.parseDouble(pct.getText().toString());
            result.setText(p+"% من "+x+" = "+(x*p/100.0));
        }catch(Exception e){result.setText("أدخل القيم بشكل صحيح");}}));
    }
    void converter() {
        page("🔄 تحويل الوحدات");
        EditText x=input("القيمة"); root.addView(x);
        root.addView(btn("كيلومتر → متر",v->{try{x.setText(""+(Double.parseDouble(x.getText().toString())*1000));}catch(Exception e){}}));
        root.addView(btn("متر → كيلومتر",v->{try{x.setText(""+(Double.parseDouble(x.getText().toString())/1000));}catch(Exception e){}}));
        root.addView(btn("كيلوغرام → غرام",v->{try{x.setText(""+(Double.parseDouble(x.getText().toString())*1000));}catch(Exception e){}}));
        root.addView(btn("غرام → كيلوغرام",v->{try{x.setText(""+(Double.parseDouble(x.getText().toString())/1000));}catch(Exception e){}}));
    }
    void qr() {
        page("🔳 إنشاء QR");
        EditText e=input("اكتب النص أو الرابط"); root.addView(e);
        root.addView(btn("إنشاء QR",v->{new AlertDialog.Builder(this).setTitle("نسخة تجريبية").setMessage("تم تجهيز مكان أداة QR. في النسخة التالية نضيف توليد صورة QR وحفظها.").setPositiveButton("حسنًا",null).show();}));
    }
    void textTools() {
        page("📝 أدوات النص");
        EditText e=input("اكتب النص هنا"); e.setMinLines(5); root.addView(e);
        result=new TextView(this); result.setTextSize(18); root.addView(result);
        root.addView(btn("عدد الأحرف والكلمات",v->{String s=e.getText().toString(); int words=s.trim().isEmpty()?0:s.trim().split("\\s+").length; result.setText("الأحرف: "+s.length()+"\nالكلمات: "+words);}));
    }
    @Override public void onCreate(Bundle b){super.onCreate(b); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(10,10,10,10);ScrollView sv=new ScrollView(this);sv.addView(root);setContentView(sv);showHome();}
}
